export default {
    "data": {
        // "type": "短期作业",
        // "cd_type": "超车道",
        "model": [{
            "id": 1,//标签类别ID，对应模型数据里的bsid
            "name": "限速1",//标识类别名称
            "path": "./models/bs/40-B.glb",//标识模型的地址
        },{
            "id": 2,//标签类别ID，对应模型数据里的bsid
            "name": "限速2",//标识类别名称
            "path": "./models/bs/变道-S.glb",//标识模型的地址
        },{
            "id": 3,//标签类别ID，对应模型数据里的bsid
            "name": "限速3",//标识类别名称
            "path": "./models/bs/双向-B.glb",//标识模型的地址
        }]
    }
}